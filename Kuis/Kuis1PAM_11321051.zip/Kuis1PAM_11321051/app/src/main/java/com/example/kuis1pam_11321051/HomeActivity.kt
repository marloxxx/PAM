package com.example.kuis1pam_11321051

import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity(){
    override fun onStart() {
        super.onStart()
        setContentView(R.layout.activity_home)
    }
}
