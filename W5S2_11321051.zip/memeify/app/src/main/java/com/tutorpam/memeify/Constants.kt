package com.tutorpam.memeify

const val IMAGE_URI_KEY = "IMAGE_URI"
const val BITMAT_WIDTH = "BITMAT_WIDTH"
const val BITMAT_HEIGHT = "BITMAT_HEIGHT"