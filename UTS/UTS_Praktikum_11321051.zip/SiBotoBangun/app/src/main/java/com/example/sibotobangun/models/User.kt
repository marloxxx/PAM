package com.example.sibotobangun.models

data class User(
    val nik: String,
    val fullname: String,
    val phone: String,
    val email: String,
    val password: String
)
