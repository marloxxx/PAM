package com.example.sibotobangun.app

import android.view.View
import androidx.lifecycle.ViewModel

class ShapesViewModel : ViewModel(){

    val navigateToSquare = View.OnClickListener {

    }

    val navigateToRectangle = View.OnClickListener {

    }
}
