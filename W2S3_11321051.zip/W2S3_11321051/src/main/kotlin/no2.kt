fun printSum2(a:Int, b:Int){
    println("sum of $a and $b is ${a+b}")
}
// fungsi printSum2 tidak memiliki return type dan memiliki parameter a dan b bertipe Int
// fungsi ini sama dengan fungsi printSum1 hanya saja fungsi printSum2 tidak memiliki return type

fun main() {
    printSum2(-1, 8)
}