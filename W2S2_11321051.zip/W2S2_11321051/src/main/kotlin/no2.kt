fun sum2(a:Int, b:Int) = a + b
// fungsi sum2 adalah bentuk singkat dari fungsi sum1
// dimana fungsi sum2 tidak memiliki return type dan tidak memiliki tanda kurung kurawal di dalam fungsi tersebut

fun main(){
    println("sum of 19 and 23 is ${sum2(19, 23)}")
}