fun main() {
    val items = listOf("apple", "banana", "kiwifruit") // deklarasi variabel items dengan tipe data List<String> dan nilai ["apple", "banana", "kiwifruit"]
    for (item in items){
        println(item)
    }
//    dilakukan iterasi terhadap setiap item di dalam items untuk menampilkan item tersebut
}