fun printSum1(a:Int, b:Int): Unit{
    println("sum of $a and $b is ${a + b}")
}
// fungsi printSum1 memiliki return type Unit dan memiliki parameter a dan b bertipe Int
// fungsi printSum1 akan menampilkan output sum of a and b is a + b

fun main() {
    printSum1(-1, 8)
}