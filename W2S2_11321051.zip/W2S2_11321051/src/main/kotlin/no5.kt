fun main() {
    var x = 5 // `Int` type inferred
    x += 1 // x ditambah 1 dan hasilnya disimpan kembali ke x, hal ini sama dengan x = x + 1
    print("x = $x")
}