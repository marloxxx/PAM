fun sum1(a:Int, b:Int):Int{
    return a + b
}
// fungsi dengan return type Int dan parameter a dan b bertipe Int dimana nilai kembalian dari fungsi ini adalah a + b

fun main() {
    print("sum of 3 and 5 is ")
    println(sum1(3, 5)) // fungsi sum1 dipanggil dengan parameter 3 dan 5 dan hasilnya ditampilkan di layar dengan println
}